## CI-3725
Descomprima los archivos del analizador en una carpeta, ingrese en una terminal ubicado dentro de ella y ejecute la siguiente instrucción: “./lex <nombre del archivo>”.

	En caso de existir algún error, revisar que el script tiene los permisos necesarios para ser ejecutado. También se puede presentar el caso en el que archivo ingresado no existe o no se le asigna un argumento al script, en ambos casos el mismo arrojará un error de “Error al procesar el archivo de entrada”

